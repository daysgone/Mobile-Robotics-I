#!/usr/bin/env python

# Movement model adapted from: 2D Monte Carlo Particle Filter Localizer
# By: Eric Marcoux
# For: Mobile Robots - PS6
import numpy as np
import rospy as rp
from robot import PARTICLE
from functools import partial

last_time = None
angles = None


# particle_filter(particle set, action taken, the laser readings)
def move_particles(ps, control):
    global last_time
    if last_time is None:
        last_time = rp.get_rostime()

    # probabilistically move all the particles
    new_pos = partial(integrate_control_to_distance, control, (rp.get_rostime() - last_time).to_sec())
    last_time = rp.get_rostime()
    for particle in ps:
        # create particles for each main particle with possible poses
        # need to use scan matching to find best pose

        particle.pose = new_pos(particle.pose)


# convert polar control and initial position into a probabilistically determined cartesian position
def integrate_control_to_distance(polar_control, dt, original_pos):
    (xo, yo, to) = original_pos
    (vl, vt) = polar_control

    std_dev = np.sqrt(vl**2 + vt**2)/6.
    if std_dev == 0.0:
        std_dev = 1.0

    vl_gauss = np.random.normal(vl, std_dev) # normalized linear velocity
    vt_gauss = np.random.normal(vt, std_dev) # normalized angular velocity

    t = to + (vt_gauss*dt)  # new angle
    t_mid = (t+to)/2.0    # take the average of the final and initial angle to for the cartesian translation

    dx = vl_gauss*np.cos(t_mid)*dt
    dy = vl_gauss*np.sin(t_mid)*dt

    # print 'vl', vl, 'vt', vt, 'dy', dy, 'dx', dx, 'stddev', std_dev, 'dt', dt
    x = xo + dx
    y = yo + dy

    return x, y, t
