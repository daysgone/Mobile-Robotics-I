import numpy as np
from numpy import array, floor, cos, sin

class RayCaster:
    # pass it the map and map_info messages
    def __init__(self, params, map_msg):
        self.params = params
        self.map = map_msg
        self.base_scan_angles = None

    def set_map(self, map):
        self.map = map

    # given a particle and a scan get
    # [[distances], [distances]]->for each particle
    def raycast(self, particles, scan_msg):
        this_particles = particles/array([self.map.info.resolution, self.map.info.resolution, 1.]) # to map coordinates
        max_range = np.floor(self.params['LASER_MAX'] / self.map.info.resolution) - 1
        got_em = False
        casted_rays = []

        if not self.base_scan_angles:
            self.base_scan_angles = array([i*scan_msg.angle_increment for i in xrange(scan_msg.ranges)])+scan_msg.angle_min


        for x, y, theta, in particles:
            angles = self.base_scan_angles + theta
            rays = zip(cos(angles), sin(angles))
            distances = []

            for cosine, sine in rays:
                for i in xrange(max_range):
                    dx = floor(i*cosine)
                    dy = floor(i*sine)
                    if self.map.data[(y+dy)*self.map.info.width + (x+dx)] >= self.params['l_occ']:
                        distances.append(i*self.map.info.resolution)
                        got_em = True
                        break;
                if not got_em:
                    distances.append(self.params['LASER_MAX'])
                got_em = False
            distances.append(casted_rays)

        return array(casted_rays)
