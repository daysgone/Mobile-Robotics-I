#!/usr/bin/env python
from sensor_msgs.msg import LaserScan, PointCloud2
from geometry_msgs.msg import Twist, PoseStamped, Pose, Pose2D
import std_msgs.msg
import sensor_msgs.point_cloud2 as pcl2
from nav_msgs.msg import Odometry, OccupancyGrid, MapMetaData
from utils import *  # includes rospy and numpy
from robot import PARTICLE, init_robot_file
from movement_model import move_particles

# parameters
params = {}
params['MAP_WIDTH'] = 56.
params['MAP_HEIGHT'] = 56.
params['MAP_RESOLUTION'] = .1
params['STD_DEV_HIT'] = 1.0
params['LAMBDA_SHORT'] = 1.0
params['Z_HIT'] = 0.5
params['Z_RAND'] = 0.2
params['Z_MAX'] = 0.1
params['Z_SHORT'] = 0.1
params['MAX_DIST'] = 5.0
params['l_occ'] = .9
params['l_free'] = .3
params['alpha'] = 0.1
params['PARTICLE_COUNT'] = 1

# start of globals
last_time = None
actual_pose = None


class MAPPER:
    def __init__(self):
        global params
        rp.init_node('mapper')

        params['MAP_WIDTH']      = rp.get_param('~map_width',      10.0)
        params['MAP_HEIGHT']     = rp.get_param('~map_height',     10.0)
        params['MAP_RESOLUTION'] = rp.get_param('~map_resolution',   .025)
        params['STD_DEV_HIT']    = rp.get_param('~std_dev_hit',     1.0)
        params['LAMBDA_SHORT']   = rp.get_param('~lambda_short',    1.0)
        params['Z_HIT']          = rp.get_param('~z_hit',           0.5)
        params['Z_RAND']         = rp.get_param('~z_rand',          0.2)
        params['Z_MAX']          = rp.get_param('~z_max',           0.1)
        params['Z_SHORT']        = rp.get_param('~z_short',         0.1)
        params['PARTICLE_COUNT'] = rp.get_param('~particle_count',  1)
        params['MAX_DIST']       = rp.get_param('~max_dist',        5.0)
        params['l_occ']          = rp.get_param('~l_occ',           0.9)
        params['l_free']         = rp.get_param('~l_free',          0.3)
        params['alpha']          = rp.get_param('~alpha',            .1)
        init_utils(params)
        init_robot_file(params)
        # TODO should be odometry we subscribe to
        self.last_time = rp.get_rostime()
        #self.part = PARTICLE()
        self.parset = [PARTICLE() for _ in xrange(params['PARTICLE_COUNT'])]
        self.pose = Pose2D()

<<<<<<< HEAD
        # TODO should be odometry we subscribe to
=======
        rp.Subscriber('/robot/base_scan', LaserScan, self.scan_callback, queue_size=1)
        rp.Subscriber('/pose', Pose2D, self.pose_callback, queue_size=1)
>>>>>>> origin/master
        rp.Subscriber('/stage/odom', Odometry, self.odom_callback, queue_size=1)

        self.map_pub = rp.Publisher('/map', OccupancyGrid, latch=True, queue_size=1)
        self.map_data_pub = rp.Publisher('/map_metadata', MapMetaData, latch=True, queue_size=1)
        #self.cmd_vel = rp.Publisher('/robot/cmd_vel', Twist, queue_size=1)
        #self.partset_pub = rp.Publisher('pcl', PointCloud2, queue_size=1)

        # pass current pose from stage to rviz
<<<<<<< HEAD
        self.pose_pub = rp.Publisher('/robot/pose', PoseStamped, latch=True, queue_size=1)
        self.control = (1.0, 0.0)
=======
        #self.pose_pub = rp.Publisher('/robot/pose', PoseStamped, latch=True, queue_size=1)
        self.control = (0.0, 0.0)
>>>>>>> origin/master

        # dt = (rp.get_rostime() - last_time).to_sec()

    def publish_map(self):
        """ Publish the map. """
        grid_msg = self.parset[0].map.to_message()
        #grid_msg = self.part.map.to_message()
        self.map_data_pub.publish(grid_msg.info)
        self.map_pub.publish(grid_msg)

    def publish_particles(self):
        #loop through parset and get pose from each and append to a list
        particle_tosend = []
        header = std_msgs.msg.Header()
        header.stamp = rp.Time.now()
        header.frame_id = 'map'

        for p in xrange(params['PARTICLE_COUNT']):
            #print self.parset[p].pose
            particle_tosend.append(self.parset[p].pose)

        #create pcl from points
        particle_msg = pcl2.create_cloud_xyz32(header, particle_tosend)
        self.partset_pub.publish(particle_msg)

    def scan_callback(self, scan):
        """
        :param scan:
        :return: nothing
        """
<<<<<<< HEAD
        self.part.map = occupancy_grid_mapping(self.part.map, self.pose.pose, scan)
=======
        '''
         # loop through each particle
        for k in range(PARTICLE_COUNT):
            # scan match here cur_pose = argmax(sample_motion_model(odo, dt, particles[k]))
            # likelihood of measurement = measurement_model_map( sensor reading, current pose, previous map)
            # new occupancy grid map = updated_occupancy_grid( sensor, current pose, prev map)
            # map = occupancy_grid_mapping(map_prior, pose, scan)
            #print k
            # add new particle to temp list

        # resample
        #for k in xrange(PARTICLE_COUNT):
            #draw with probability based on weight
            # add point to list
        '''

        #move_particles(self.parset, self.control)
        for p in self.parset:
            #p.weight = measurement_model_map(self.parset[x].map, self.pose.pose, scan)
            p.map = occupancy_grid_mapping(p.map, self.pose, scan)
            #self.parset[x].map = occupancy_grid_mapping(self.parset[x].map, self.pose.pose, scan)

        #self.part.map = occupancy_grid_mapping(self.part.map, self.pose.pose, scan)
        #self.parset = new_parset
>>>>>>> origin/master
        # Now that the map is updated, publish it!
        rp.loginfo("Scan is processed, publishing updated map.")
        self.publish_map()
        #
        # self.publish_particles()

    def odom_callback(self, msg):
        """ update actual pose from msg from stage
        :param msg: frame odom, twist and pose
        :return: nothing
        """

        #self.pose.header.frame_id = "/base_link"
        #self.pose.header.stamp = rp.Time.now()
        #print "callback ", msg

        #self.pose = msg
        self.control = (msg.twist.twist.linear.x, msg.twist.twist.angular.z)
        #print "to send out", self._pose
        #self._pose_pub.publish(self._pose)

    def pose_callback(self, msg):
        """ update actual pose from msg from stage
        :param msg: frame odom, twist and pose
        :return: nothing
        """

        #self.pose.header.frame_id = "/base_link"
        #self.pose.header.stamp = rp.Time.now()
        #print "callback ", msg

        self.pose = msg
        #self.control = (msg.twist.twist.linear.x, msg.twist.twist.angular.z)
        #print "to send out", self._pose

if __name__ == '__main__':
    try:
        m = MAPPER()
        #print"particle set contains", m.get_parset()
        rp.spin()

    except rp.ROSInterruptException:
        pass
