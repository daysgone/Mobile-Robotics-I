<<<<<<< HEAD
=======
import rospy
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import PointCloud2
>>>>>>> origin/master
from geometry_msgs.msg import Pose, Point, Quaternion
from nav_msgs.msg import OccupancyGrid

<<<<<<< HEAD
from utils import *
=======
params = {}


def init_robot_file(m_params):
    global params
    params = m_params
>>>>>>> origin/master


class PARTICLE:
    """
    Docstring
    """
    def __init__(self):
<<<<<<< HEAD
        # parameters
        MAP_WIDTH      = rp.get_param('/map_width')
        MAP_HEIGHT     = rp.get_param('/map_height')
        STD_DEV_HIT    = rp.get_param('/std_dev_hit')
        LAMBDA_SHORT   = rp.get_param('/lambda_short')
        Z_HIT          = rp.get_param('/z_hit')
        Z_RAND         = rp.get_param('/z_rand')
        Z_MAX          = rp.get_param('/z_max')
        Z_SHORT        = rp.get_param('/z_short')
        MAX_DIST       = rp.get_param('/max_dist')
        PARTICLE_COUNT = rp.get_param('/particle_count')
        self.x = np.random.random() * MAP_WIDTH
        self.y = np.random.random() * MAP_HEIGHT
        self.theta = np.random.random() * 2.0 * np.pi
=======
        self.x = params['MAP_WIDTH']/2  # np.random.random() * params['MAP_WIDTH']
        self.y = params['MAP_HEIGHT']/2  # np.random.random() * params['MAP_HEIGHT']
        self.theta = 0.0 # np.random.random() * 2.0 * np.pi
>>>>>>> origin/master
        self.weight = 1.0
        self.pose = self.x, self.y, self.theta
        # map needs size information to be used correctly
        self.map = MAP(origin_x=-params['MAP_WIDTH']/2,
                       origin_y=-params['MAP_HEIGHT']/2,
                       resolution=params['MAP_RESOLUTION'],
                       width=params['MAP_WIDTH'],
                       height=params['MAP_HEIGHT'])

    def move(self, polar_control, dt):
        """
        :param polar_control: linear and angular velocities
        :param dt: change in time
        :return: updated object
        """
        (xo, yo, to) = self.pose
        (vl, vt) = polar_control

        std_dev = np.sqrt(vl**2 + vt**2)
        if std_dev == 0.0:
            std_dev = 1.0

<<<<<<< HEAD
    def move(self, con):
=======
        vl_gauss = np.random.normal(vl, std_dev) # normalized linear velocity
        vt_gauss = np.random.normal(vt, std_dev) # normalized angular velocity

        t = to + (vt_gauss*dt)  # new angle
        t_mid = (t+to)/2.0    # take the average of the final and initial angle to for the cartesian translation
>>>>>>> origin/master

        dx = vl_gauss*np.cos(t_mid)*dt
        dy = vl_gauss*np.sin(t_mid)*dt

        # print 'vl', vl, 'vt', vt, 'dy', dy, 'dx', dx, 'stddev', std_dev, 'dt', dt
        x = xo + dx
        y = yo + dy
        self.pose = (x, y, t)

        return self  # updated values

    def measurement_prob(self, scan):
        """
        Take laser scan data and compare it to particles position by use of
            raycaster. Compute weight by summing up the quality of readings from each scan

        :param scan:    laser scan msg
        :return:        weight of particle based on correct pose
        """

        # take laser scan and compare it to raycaster for particles position
        # number of laser scans
        # scan_count = int((scan.angle_max - scan.angle_min) / scan.angle_increment) + 1
        # beams = np.arange(scan.angle_min, scan.angle_max + 0.01, scan.angle_increment)  # needed .01 to give first beam

        # from eric m
        # precomputes the coefficient and exponent base for faster normal calculations
<<<<<<< HEAD
=======
        STD_DEV_HIT = params['STD_DEV_HIT']
>>>>>>> origin/master
        p_hit_coeff = 1./(np.sqrt(2*np.pi*STD_DEV_HIT*STD_DEV_HIT))
        p_hit_exp   = np.exp(-1./(2.*STD_DEV_HIT*STD_DEV_HIT))

        def p_hit(sensed_distance, raytraced_distance):
            if sensed_distance > params['MAX_DIST']:
                return 0.0
            return p_hit_coeff*(p_hit_exp**((sensed_distance - raytraced_distance)**2))

        def p_max(sensed_distance, raytraced_distance):
            if sensed_distance == params['MAX_DIST']:
                return 1.0
            return 0.0

        def p_rand(sensed_distance, raytraced_distance):
            if sensed_distance < params['MAX_DIST']:
                return 0.0
            return 1./params['MAX_DIST']

        scan_min = scan.angle_min
        scan_inc = scan.angle_increment

        prob = 1.0
        for l in xrange(len(scan.ranges)):
            sensed = scan.ranges[l]
<<<<<<< HEAD
            traced = mcl_tools.map_range(self, scan_min + (l * scan_inc))
            prob *= Z_HIT * p_hit(sensed, traced) \
                    + Z_RAND * p_rand(sensed, traced) \
                    + Z_MAX * p_max(sensed, traced)
=======
            # traced = mcl_tools.map_range(self, scan_min + (l * scan_inc))
            # need to get closest occupied per scan line
            traced = 0
            prob *= params['Z_HIT'] * p_hit(sensed, traced) \
                    + params['Z_RAND'] * p_rand(sensed, traced) \
                    + params['Z_MAX'] * p_max(sensed, traced)
>>>>>>> origin/master

        self.set_weight(prob)
        #print "particle prob ", prob

        return prob

    def __repr__(self):
        return '[x=%.6s y=%.6s theta=%.6s]' % (str(self.x), str(self.y), str(self.theta))


class MAP:
    """
    The Map class stores an occupancy grid as a two dimensional
    numpy array.

    """
    # need to change defaults if not using hallway map from stage 53.900 10.600
    def __init__(self, origin_x=-26.95, origin_y=-5.0, resolution=0.1, width=53.3, height=10.9):
        """
        :param origin_x:    Position of the grid cell (0,0)

        :param origin_y:    in the map coordinate system.
        :param resolution:  Width of each grid square in meters.
        :param width:       meter
        :param height:
        :return:
        """
        self.origin_x = origin_x  # global cord
        self.origin_y = origin_y
        self.resolution = resolution
        self.width = width/self.resolution  # convert to # of cells
        self.height = height/self.resolution  # convert to # of cells
        self.grid = np.ones((self.height, self.width)) * logit(.5)

    def to_message(self):
        """ Return a nav_msgs/OccupancyGrid representation of this map. """
        grid_msg = OccupancyGrid()

        # Set up the header.
        grid_msg.header.stamp = rp.Time.now()
        grid_msg.header.frame_id = "/map"

        # .info is a nav_msgs/MapMetaData message.
        grid_msg.info.resolution = self.resolution
        grid_msg.info.width = self.width
        grid_msg.info.height = self.height

        # Rotated maps are not supported... quaternion represents no
        # rotation.
        grid_msg.info.origin = Pose(Point(self.origin_x, self.origin_y, 0),
                               Quaternion(0, 0, 0, 1))


        # Flatten the numpy array
        flat_grid = self.grid.reshape((self.grid.size,))
        # need to go from lod_odds to 0-100
        flat_grid = [unlogit(i)*100 for i in flat_grid]

        grid_msg.data = list(np.round(flat_grid))  # converts to int
        return grid_msg

