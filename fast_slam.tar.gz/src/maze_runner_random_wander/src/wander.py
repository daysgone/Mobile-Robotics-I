#!/usr/bin/env python
import rospy as rp
import numpy as np
rp.init_node('wander')
from math import atan2

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist

cmd_vel = None
angles = None

ANGULAR_SCALE = 10.0
LINEAR_SCALE = 0.2 

def got_scan(msg):
    global cmd_vel, angles

    if angles is None: # statically use it after initialization (message shouldn't change length while it's running)
        angles = np.multiply(range(len(msg.ranges)), msg.angle_increment) + msg.angle_min

    measurements = zip(msg.ranges, angles)
    fx = np.sum([l*np.cos(t) for l,t in measurements])
    fy = np.sum([l*np.sin(t) for l,t in measurements])

    linear_speed = LINEAR_SCALE*(msg.ranges[2]) # scale the speed by the range on the front sensor
    angular_speed = (ANGULAR_SCALE/msg.ranges[2])*atan2(fy,fx)
    control = (linear_speed, angular_speed)

    cmd = Twist()
    (cmd.linear.x, cmd.angular.z) = control
    cmd_vel.publish(cmd)


if __name__ == '__main__':
	rp.init_node('wander')

	LINEAR_SCALE = rp.get_param('~linear_scale', 0.2)
	ANGULAR_SCALE = rp.get_param('~angular_scale', 10.0)

	cmd_vel = rp.Publisher('/robot/cmd_vel', Twist, queue_size=1)
	rp.Subscriber('/robot/base_scan', LaserScan, got_scan, queue_size=1)
	rp.spin()
