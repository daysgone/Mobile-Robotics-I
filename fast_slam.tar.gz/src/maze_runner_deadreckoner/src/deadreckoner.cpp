#include <ros/ros.h>
#include <ros/time.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/Twist.h>
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/PoseWithCovariance.h>
#include <geometry_msgs/TwistWithCovariance.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Quaternion.h>

#include <math.h>

ros::Publisher odom_pub;
ros::Subscriber twist_sub;
ros::Time last_time;
bool time_set = false;

double x = 0.0, y = 0.0, theta = 0.0;

void twist_cb(const geometry_msgs::Twist::ConstPtr& msg) {
  ros::Time now = ros::Time::now();
  nav_msgs::Odometry odom_msg;
  odom_msg.twist.twist = *msg;
  odom_msg.header.stamp = now;
  odom_msg.header.frame_id = "odom";
  odom_msg.child_frame_id = "base_link";

  if(time_set) {
    const double del_t = (now - last_time).toSec();

    theta += odom_msg.twist.twist.angular.z * del_t;
    x += odom_msg.twist.twist.linear.x * cos(theta) * del_t; 
    y += odom_msg.twist.twist.linear.x * sin(theta) * del_t; 

    odom_msg.pose.pose.position.x = x;
    odom_msg.pose.pose.position.y = y;
    odom_msg.pose.pose.position.z = 0.0;
    odom_msg.pose.pose.orientation = tf::createQuaternionMsgFromYaw(theta);
    last_time = ros::Time::now();
  } else {
    last_time = ros::Time::now();
    time_set = true;
    odom_msg.pose.pose.position.x = x;
    odom_msg.pose.pose.position.y = y;
    odom_msg.pose.pose.position.z = 0.0;
    odom_msg.pose.pose.orientation = tf::createQuaternionMsgFromYaw(0);
  }
}

int main(int argc, char **argv) {
  ros::init(argc, argv, "deadreckoner");
  ros::NodeHandle n;

  tf::TransformBroadcaster odom_broadcaster;
  odom_pub = n.advertise<nav_msgs::Odometry>("odom", 1);
  twist_sub = n.subscribe("cmd_vel", 1, twist_cb);
  geometry_msgs::TransformStamped odom_trans;
  odom_trans.header.frame_id = "odom";
  odom_trans.child_frame_id = "base_link";
  
  ros::Rate rate(10);
  while(ros::ok()) {
    odom_trans.header.stamp = ros::Time::now();
    odom_trans.transform.translation.x = x;
    odom_trans.transform.translation.y = y;
    odom_trans.transform.translation.z = 0.0;
    odom_trans.transform.rotation = tf::createQuaternionMsgFromYaw(theta);

    ros::spinOnce();
    rate.sleep();
  }
  return 0;
}
