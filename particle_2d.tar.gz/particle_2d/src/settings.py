#!/usr/bin/env python
__author__ = 'bday'


def init():
    global MAP_WIDTH
    global MAP_HEIGHT
    global Z_HIT
    global Z_RAND
    global Z_MAX
    global STD_DEV_HIT
    global PARTICLE_COUNT
    MAP_WIDTH = 53.9
    MAP_HEIGHT = 10.6
    STD_DEV_HIT = 1.0
    Z_HIT = 0.6
    Z_RAND = 0.3
    Z_MAX = 0.1
    PARTICLE_COUNT = 5




